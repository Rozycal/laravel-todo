<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-2">
        </div>
        <div class="col-md-8">
            <div id="app" class="todolist not-done">
                <h1>To Do List</h1><hr>
                    <form action="<?php echo e(route('todos.edit')); ?>" method="post">
                    <?php echo $__env->make("partials.errors", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <div class="new-todo">
                            <input type="text" class="form-control add-todo" name="name" id="name" value="<?php echo e($todo->name); ?>"/>

                            <span class="pull-left" >
                                <input type="hidden" name="id" value="<?php echo e($todoId); ?>">
                                <button type="submit" class="btn btn-primary" id="todoButtons">Edit</button>
                                <a href="<?php echo e(route('todos.index')); ?>" class="btn btn-primary" id="todoButtons">Back</a>
                            </span>
                        </div>
                        <?php echo e(csrf_field()); ?>

                    </form>
                    <?php if(Session::has("info")): ?>
                    <div class="row" id="alert-info">
                        <div class="col-md-12">
                            <p class="alert alert-info"><?php echo e(Session::get('info')); ?></p>
                        </div>
                    </div>
                    <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>