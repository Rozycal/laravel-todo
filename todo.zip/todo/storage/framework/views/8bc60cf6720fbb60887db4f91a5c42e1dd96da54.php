<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-2">
        </div>
        <div class="col-md-8">
            <div id="app" class="todolist not-done">
                <div>
                    <h1>Todos</h1>
                        <div class="new-todo">
                            <input type="text" class="form-control add-todo" placeholder="New todo"/>
                            <span>
                                <button class="btn btn-success pull-left">Add Todo</button>
                            </span>
                        </div>
                </div>
            </div>
        </div>
        <div class="col-md-2">
        </div>
    </div>
    <hr/>
    <div class="row">
     <div class="col-md-2">
        </div>
        <div class="col-md-8">
            <div id="app" class="todolist not-done">
                <div>
                        <ul id="sortable" class="list-unstyled">
                            <li class="ui-state-default">
                                <div class="checked">
                                    <label >Clean house</label>
                                    <span class="todo-buttons pull-right">
                                        <button class="btn">Delete</button>
                                     </span>
                                </div>
                            </li>
                            <hr>
                            <li class="ui-state-default">
                                <div class="">
                                    <label >Fix window</label>
                                    <span class="todo-buttons pull-right">
                                        <button class="btn">Delete</button>
                                     </span>
                                </div>
                            </li>
                        </ul>
                    <div class="todo-footer">
                        <strong><span class="count-todos"></span></strong> Items Left to do: 1
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-2">
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>