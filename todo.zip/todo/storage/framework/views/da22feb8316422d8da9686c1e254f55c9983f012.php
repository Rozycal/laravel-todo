<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-2">
        </div>
        <div class="col-md-8">
            <div id="app" class="todolist not-done">
                <h1>To Do List</h1><hr>
                    <form action="<?php echo e(route('todos.create')); ?>" method="post">
                    <?php echo $__env->make("partials.errors", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <div class="new-todo">
                            <input type="text" class="form-control add-todo" name="name" id="name" placeholder="Please type a new todo"/>
                            <span>
                                <button type="submit" class="btn btn-primary pull-left">Add Todo</button>
                            </span>
                        </div>
                        <?php echo e(csrf_field()); ?>

                    </form>
                    <?php if(Session::has("info")): ?>
                    <div class="row" id="alert-info">
                        <div class="col-md-12">
                            <p class="alert alert-success"><?php echo e(Session::get('info')); ?></p>
                        </div>
                    </div>
                    <?php endif; ?>
                <hr>
                <ul id="sortable" class="list-unstyled">
                <?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="ui-state-default">
                                <?php if($todo->finished): ?>
                                <div class="checked">
                                    <label ><?php echo e($todo->name); ?></label>
                                    <span class="todo-buttons pull-right">
                                        <a href="<?php echo e(route('todos.delete',['id'=>$todo->id])); ?>" class="btn btn-primary">Delete</a>
                                        <a href="<?php echo e(route('todos.todo',['id'=> $todo->id ])); ?>" class="btn btn-primary">Edit</a>
                                     </span>
                                </div>
                                <?php else: ?>
                                <div class="">
                                    <label ><?php echo e($todo->name); ?></label>
                                    <span class="todo-buttons pull-right">
                                        <a href="<?php echo e(route('todos.finish',['id'=>$todo->id])); ?>" class="btn btn-primary">Finish</a>
                                        <a href="<?php echo e(route('todos.delete',['id'=>$todo->id])); ?>"" class="btn btn-primary">Delete</a>
                                        <a href="<?php echo e(route('todos.todo',['id'=> $todo->id ])); ?>" class="btn btn-primary">Edit</a>
                                     </span>
                                </div>
                                <?php endif; ?>
                            </li>
                            <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                 <div class="todo-footer">
                    <strong><span class="count-todos"></strong></span>Items left to do: <?php echo e(count($todo->all()->where('finished','=',0))); ?>

                </div>
            </div>
        </div>
        <div class="col-md-2">
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 text-center">
        <?php echo $todos->render(); ?>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>