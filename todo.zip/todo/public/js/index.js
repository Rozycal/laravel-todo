/*
  index.js
*/
//$(document).ready(function()){

"use strict";




