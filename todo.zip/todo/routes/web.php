<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get("todos", [
                "uses"=>"todoController@getIndex",
                "as"=>"todos.index"]);

Route::get("todos/{id}", [
                "uses"=>"todoController@getTodo",
                "as"=>"todos.todo"]);

Route::post("create", [
                "uses"=>"todoController@postTodoCreate",
                "as"=>"todos.create"]);

Route::get("create",[
                "uses"=>"todoController@getTodoCreate",
                "as"=>"todos.create"]);

Route::get("delete/{id}",[
                "uses"=>"todoController@getTodoDelete",
                "as"=>"todos.delete"]);

Route::post("todos", [
                "uses"=>"todoController@postTodoEdit",
                "as"=>"todos.edit"]);

Route::get("finish/{id}", [
                "uses"=>"todoController@getTodoFinished",
                "as"=>"todos.finish"]);