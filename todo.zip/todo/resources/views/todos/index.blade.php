@extends('layouts.master')

@section('content')

<div class="container">
    <div class="row">
        <div class="col-md-2">
        </div>
        <div class="col-md-8">
            <div id="app" class="todolist not-done">
                <h1>To Do List</h1><hr>
                    <form action="{{route('todos.create')}}" method="post">
                    @include("partials.errors")
                        <div class="new-todo">
                            <input type="text" class="form-control add-todo" name="name" id="name" placeholder="Please type a new todo"/>
                            <span>
                                <button type="submit" class="btn btn-primary pull-left">Add Todo</button>
                            </span>
                        </div>
                        {{csrf_field()}}
                    </form>
                    @if(Session::has("info"))
                    <div class="row" id="alert-info">
                        <div class="col-md-12">
                            <p class="alert alert-success">{{Session::get('info')}}</p>
                        </div>
                    </div>
                    @endif
                <hr>
                <ul id="sortable" class="list-unstyled">
                @foreach($todos as $todo)
                            <li class="ui-state-default">
                                @if($todo->finished)
                                <div class="checked">
                                    <label >{{ $todo->name }}</label>
                                    <span class="todo-buttons pull-right">
                                        <a href="{{ route('todos.delete',['id'=>$todo->id]) }}" class="btn btn-primary">Delete</a>
                                        <a href="{{ route('todos.todo',['id'=> $todo->id ]) }}" class="btn btn-primary">Edit</a>
                                     </span>
                                </div>
                                @else
                                <div class="">
                                    <label >{{ $todo->name }}</label>
                                    <span class="todo-buttons pull-right">
                                        <a href="{{ route('todos.finish',['id'=>$todo->id]) }}" class="btn btn-primary">Finish</a>
                                        <a href="{{ route('todos.delete',['id'=>$todo->id]) }}"" class="btn btn-primary">Delete</a>
                                        <a href="{{ route('todos.todo',['id'=> $todo->id ]) }}" class="btn btn-primary">Edit</a>
                                     </span>
                                </div>
                                @endif
                            </li>
                            <hr>
                @endforeach
                </ul>
                 <div class="todo-footer">
                    <strong><span class="count-todos"></strong></span>Items left to do: {{count($todo->all()->where('finished','=',0))}}
                </div>
            </div>
        </div>
        <div class="col-md-2">
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 text-center">
        {!! $todos->render() !!}
        </div>
    </div>
</div>

@endsection

